import math
import struct
import threading
import unittest
import urllib.error
import urllib.request
import wave
import io
import http.client
import subprocess
from http.server import ThreadingHTTPServer

import numpy as np

from app.audio import read_audio_bytes
from app.service import Handler


def tone_wav():
    output = io.BytesIO()
    with wave.open(output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(b"".join(struct.pack("<h", int(10000 * math.sin(2 * math.pi * 440 * i / 16000))) for i in range(16000)))
    return output.getvalue()


def tone_mp3():
    return subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "wav", "-i", "pipe:0", "-c:a", "libmp3lame", "-b:a", "128k", "-f", "mp3", "pipe:1"],
        input=tone_wav(), stdout=subprocess.PIPE, check=True,
    ).stdout


class StreamProcessingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.server.daemon_threads = True
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.endpoint = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_process_endpoint_decodes_applies_gain_and_encodes_mp3(self):
        source = tone_mp3()
        request = urllib.request.Request(
            self.endpoint + "/process?gain=0.25", data=source,
            headers={"Content-Type": "audio/mpeg"}, method="POST",
        )
        with urllib.request.urlopen(request, timeout=20) as response:
            encoded = response.read()
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers.get_content_type(), "audio/mpeg")
            self.assertEqual(response.headers.get("X-Smart-Radio-Processor"), "ffmpeg-pcm-gain")

        original_samples = read_audio_bytes(source)
        processed_samples = read_audio_bytes(encoded)
        original_rms = float(np.sqrt(np.mean(np.square(original_samples))))
        processed_rms = float(np.sqrt(np.mean(np.square(processed_samples))))
        self.assertGreater(len(encoded), 1000)
        self.assertAlmostEqual(processed_rms / original_rms, 0.25, delta=0.04)

    def test_invalid_gain_is_rejected(self):
        request = urllib.request.Request(
            self.endpoint + "/process?gain=1.5", data=tone_wav(), method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(request, timeout=5)
        self.assertEqual(error.exception.code, 400)

    def test_chunked_input_returns_audio_before_the_request_finishes(self):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=20)
        source = tone_mp3()
        connection.putrequest("POST", "/process?gain=0.5")
        connection.putheader("Transfer-Encoding", "chunked")
        connection.endheaders()
        connection.send(f"{len(source):X}\r\n".encode() + source + b"\r\n")
        response = connection.getresponse()
        self.assertEqual(response.status, 200)
        self.assertEqual(len(response.read(1024)), 1024)
        connection.close()


if __name__ == "__main__":
    unittest.main()
