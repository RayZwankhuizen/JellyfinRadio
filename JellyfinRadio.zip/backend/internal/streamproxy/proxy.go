package streamproxy

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type StationSource interface {
	StreamURL(context.Context, string) (string, error)
}

type Proxy struct {
	source       StationSource
	client       *http.Client
	processorURL string
	dspEnabled   bool
	dspSlots     chan struct{}
	metadataMu   sync.RWMutex
	metadata     map[string]StreamMetadata
}

type StreamMetadata struct {
	Title     string    `json:"title"`
	Artist    string    `json:"artist"`
	Track     string    `json:"track"`
	StreamURL string    `json:"stream_url"`
	Received  bool      `json:"received"`
	UpdatedAt time.Time `json:"updated_at"`
}

func New(source StationSource, allowPrivateHosts bool) *Proxy {
	transport := &http.Transport{
		Proxy: nil,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			return dialPublic(ctx, network, address, allowPrivateHosts)
		},
		ResponseHeaderTimeout: 15 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		IdleConnTimeout:       60 * time.Second,
		MaxConnsPerHost:       4,
		MaxIdleConnsPerHost:   2,
	}
	processorURL := strings.TrimRight(os.Getenv("AUDIO_SERVICE_URL"), "/")
	if processorURL == "" {
		processorURL = "http://smart-radio-audio:8790"
	}
	dspEnabled, _ := strconv.ParseBool(os.Getenv("AUDIO_DSP_ENABLED"))
	return &Proxy{
		source:       source,
		client:       &http.Client{Transport: transport, CheckRedirect: validateRedirect},
		processorURL: processorURL,
		dspEnabled:   dspEnabled,
		dspSlots:     make(chan struct{}, 1),
		metadata:     make(map[string]StreamMetadata),
	}
}

func (p *Proxy) Metadata(id string) StreamMetadata {
	p.metadataMu.RLock()
	defer p.metadataMu.RUnlock()
	return p.metadata[id]
}

func (p *Proxy) OpenLearningStream(ctx context.Context, id string, onMetadata func(string)) (io.ReadCloser, error) {
	target, err := p.source.StreamURL(ctx, id)
	if err != nil {
		return nil, err
	}
	if err := validateStreamURL(target); err != nil {
		return nil, err
	}
	response, err := p.openAudio(ctx, target)
	if err != nil {
		return nil, err
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 || isPlaylist(response.Header.Get("Content-Type")) {
		response.Body.Close()
		return nil, fmt.Errorf("station stream is unavailable or is an HLS playlist")
	}
	metadata := func(title string) {
		p.setMetadata(id, title)
		if onMetadata != nil {
			onMetadata(title)
		}
	}
	stripICYMetadata(response, metadata)
	return &reconnectingBody{proxy: p, ctx: ctx, target: target, body: response.Body, onMetadata: metadata}, nil
}

func (p *Proxy) clearMetadata(id string) {
	p.metadataMu.Lock()
	p.metadata[id] = StreamMetadata{UpdatedAt: time.Now().UTC()}
	p.metadataMu.Unlock()
}

func (p *Proxy) setMetadata(id, title string) {
	title = strings.TrimSpace(strings.ToValidUTF8(title, "�"))
	metadata := StreamMetadata{Title: title, Track: title, Received: true, UpdatedAt: time.Now().UTC()}
	if split := strings.Index(title, " - "); split > 0 {
		metadata.Artist = strings.TrimSpace(title[:split])
		metadata.Track = strings.TrimSpace(title[split+3:])
	}
	p.metadataMu.Lock()
	p.metadata[id] = metadata
	p.metadataMu.Unlock()
}

func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	const prefix = "/stream/"
	if !strings.HasPrefix(r.URL.Path, prefix) || strings.TrimPrefix(r.URL.Path, prefix) == "" || strings.Contains(strings.TrimPrefix(r.URL.Path, prefix), "/") {
		http.NotFound(w, r)
		return
	}
	id, err := url.PathUnescape(strings.TrimPrefix(r.URL.EscapedPath(), prefix))
	if err != nil || id == "" {
		http.Error(w, "invalid station id", http.StatusBadRequest)
		return
	}
	streamURL, err := p.source.StreamURL(r.Context(), id)
	if err != nil {
		http.Error(w, "station not found", http.StatusNotFound)
		return
	}
	if err := validateStreamURL(streamURL); err != nil {
		http.Error(w, "invalid station stream URL", http.StatusBadGateway)
		return
	}
	p.clearMetadata(id)
	onMetadata := func(title string) { p.setMetadata(id, title) }
	if p.dspEnabled {
		if settings, ok := p.source.(interface {
			StreamDSPSettings(context.Context, string) (bool, float64, error)
		}); ok {
			enabled, gain, settingsErr := settings.StreamDSPSettings(r.Context(), id)
			if settingsErr == nil && enabled && p.tryProcessed(w, r, streamURL, gain, onMetadata) {
				return
			}
		}
	}
	p.servePassthrough(w, r, streamURL, nil, onMetadata)
}

func (p *Proxy) servePassthrough(w http.ResponseWriter, r *http.Request, streamURL string, resp *http.Response, onMetadata func(string)) {
	var err error
	if resp == nil {
		resp, err = p.open(r.Context(), streamURL)
	}
	if err != nil {
		http.Error(w, "upstream stream unavailable", http.StatusBadGateway)
		return
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		resp.Body.Close()
		http.Error(w, "upstream stream unavailable", http.StatusBadGateway)
		return
	}
	stripICYMetadata(resp, onMetadata)
	copyStreamHeaders(w.Header(), resp.Header)
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	if flusher, ok := w.(http.Flusher); ok {
		flusher.Flush()
	}

	buffer := make([]byte, 32*1024)
	attempt := 0
	for {
		_, copyErr := io.CopyBuffer(w, resp.Body, buffer)
		resp.Body.Close()
		if r.Context().Err() != nil {
			return
		}
		if copyErr != nil {
			attempt++
		}
		for r.Context().Err() == nil {
			if !wait(r.Context(), attempt) {
				return
			}
			candidate, openErr := p.open(r.Context(), streamURL)
			if openErr == nil && candidate.StatusCode >= 200 && candidate.StatusCode < 300 {
				stripICYMetadata(candidate, onMetadata)
				resp = candidate
				attempt = 0
				break
			}
			if candidate != nil {
				candidate.Body.Close()
			}
			attempt++
		}
		if r.Context().Err() != nil {
			return
		}
	}
}

func (p *Proxy) tryProcessed(w http.ResponseWriter, r *http.Request, streamURL string, gain float64, onMetadata func(string)) bool {
	select {
	case p.dspSlots <- struct{}{}:
		defer func() { <-p.dspSlots }()
	default:
		return false
	}
	ctx, cancel := context.WithCancel(r.Context())
	upstream, err := p.openAudio(ctx, streamURL)
	if err != nil || upstream.StatusCode < 200 || upstream.StatusCode >= 300 || isPlaylist(upstream.Header.Get("Content-Type")) {
		if upstream != nil {
			upstream.Body.Close()
		}
		cancel()
		return false
	}
	stripICYMetadata(upstream, onMetadata)

	pipeReader, pipeWriter := io.Pipe()
	body := &reconnectingBody{proxy: p, ctx: ctx, target: streamURL, body: upstream.Body, onMetadata: onMetadata}
	go func() {
		_, copyErr := io.Copy(pipeWriter, body)
		_ = pipeWriter.CloseWithError(copyErr)
	}()
	processURL := fmt.Sprintf("%s/process?gain=%s", p.processorURL, strconv.FormatFloat(gain, 'f', 4, 64))
	response, connection, err := p.openProcessorStream(ctx, processURL, pipeReader)
	if err != nil || response.StatusCode < 200 || response.StatusCode >= 300 {
		if response != nil {
			response.Body.Close()
		}
		if connection != nil {
			connection.Close()
		}
		cancel()
		body.Close()
		pipeReader.Close()
		pipeWriter.Close()
		return false
	}
	defer response.Body.Close()
	defer connection.Close()
	defer cancel()
	defer body.Close()
	defer pipeReader.Close()
	defer pipeWriter.Close()
	w.Header().Set("Content-Type", "audio/mpeg")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	w.Header().Set("X-Smart-Radio-DSP", "manual-gain")
	w.WriteHeader(http.StatusOK)
	if flusher, ok := w.(http.Flusher); ok {
		flusher.Flush()
	}
	_, _ = io.Copy(w, response.Body)
	return true
}

func (p *Proxy) openProcessorStream(ctx context.Context, target string, body io.Reader) (*http.Response, net.Conn, error) {
	u, err := url.Parse(target)
	if err != nil || u.Scheme != "http" || u.Host == "" || u.User != nil {
		return nil, nil, fmt.Errorf("audio processor must use an internal HTTP URL")
	}
	connection, err := (&net.Dialer{Timeout: 5 * time.Second, KeepAlive: 30 * time.Second}).DialContext(ctx, "tcp", u.Host)
	if err != nil {
		return nil, nil, err
	}
	stopClose := context.AfterFunc(ctx, func() { _ = connection.Close() })
	path := u.RequestURI()
	if path == "" {
		path = "/"
	}
	if _, err := fmt.Fprintf(connection, "POST %s HTTP/1.1\r\nHost: %s\r\nContent-Type: application/octet-stream\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n", path, u.Host); err != nil {
		stopClose()
		connection.Close()
		return nil, nil, err
	}
	go func() {
		writer := bufio.NewWriter(connection)
		buffer := make([]byte, 32*1024)
		for {
			n, readErr := body.Read(buffer)
			if n > 0 {
				if _, err := fmt.Fprintf(writer, "%x\r\n", n); err != nil {
					_ = connection.Close()
					return
				}
				if _, err := writer.Write(buffer[:n]); err != nil {
					_ = connection.Close()
					return
				}
				if _, err := writer.WriteString("\r\n"); err != nil || writer.Flush() != nil {
					_ = connection.Close()
					return
				}
			}
			if readErr != nil {
				_, _ = writer.WriteString("0\r\n\r\n")
				_ = writer.Flush()
				return
			}
		}
	}()
	_ = connection.SetReadDeadline(time.Now().Add(20 * time.Second))
	response, err := http.ReadResponse(bufio.NewReader(connection), &http.Request{Method: http.MethodPost})
	if err != nil {
		stopClose()
		connection.Close()
		return nil, nil, err
	}
	_ = connection.SetReadDeadline(time.Time{})
	return response, connection, nil
}

func (p *Proxy) openAudio(ctx context.Context, target string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Icy-MetaData", "1")
	req.Header.Set("Accept", "audio/*,application/octet-stream,*/*")
	return p.client.Do(req)
}

func isPlaylist(contentType string) bool {
	value := strings.ToLower(contentType)
	return strings.Contains(value, "mpegurl") || strings.Contains(value, "x-mpegurl")
}

type reconnectingBody struct {
	proxy      *Proxy
	ctx        context.Context
	target     string
	body       io.ReadCloser
	onMetadata func(string)
}

func (b *reconnectingBody) Read(buffer []byte) (int, error) {
	for {
		if b.ctx.Err() != nil {
			return 0, io.EOF
		}
		n, _ := b.body.Read(buffer)
		if n > 0 {
			return n, nil
		}
		_ = b.body.Close()
		for attempt := 0; b.ctx.Err() == nil; attempt++ {
			if !wait(b.ctx, attempt) {
				return 0, io.EOF
			}
			candidate, openErr := b.proxy.openAudio(b.ctx, b.target)
			if openErr == nil && candidate.StatusCode >= 200 && candidate.StatusCode < 300 && !isPlaylist(candidate.Header.Get("Content-Type")) {
				stripICYMetadata(candidate, b.onMetadata)
				b.body = candidate.Body
				break
			}
			if candidate != nil {
				candidate.Body.Close()
			}
		}
	}
}

func (b *reconnectingBody) Close() error {
	return b.body.Close()
}

func (p *Proxy) Check(ctx context.Context, target string) (int, time.Duration, error) {
	if err := validateStreamURL(target); err != nil {
		return 0, 0, err
	}
	ctx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	started := time.Now()
	resp, err := p.open(ctx, target)
	latency := time.Since(started)
	if err != nil {
		return 0, latency, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return resp.StatusCode, latency, fmt.Errorf("stream returned %s", resp.Status)
	}
	buffer := make([]byte, 1)
	if n, err := io.ReadFull(resp.Body, buffer); err != nil || n == 0 {
		if err == nil {
			err = io.EOF
		}
		return resp.StatusCode, latency, fmt.Errorf("stream returned no audio: %w", err)
	}
	return resp.StatusCode, latency, nil
}

func (p *Proxy) open(ctx context.Context, target string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Icy-MetaData", "1")
	req.Header.Set("Accept", "*/*")
	return p.client.Do(req)
}

func validateStreamURL(raw string) error {
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" || u.User != nil {
		return fmt.Errorf("unsupported stream URL")
	}
	if _, err := strconv.Atoi(u.Port()); u.Port() != "" && err != nil {
		return fmt.Errorf("invalid stream port")
	}
	return nil
}

func validateRedirect(req *http.Request, via []*http.Request) error {
	if err := validateStreamURL(req.URL.String()); err != nil {
		return err
	}
	if len(via) >= 10 {
		return fmt.Errorf("too many stream redirects")
	}
	return nil
}

func copyStreamHeaders(dst, src http.Header) {
	for key, values := range src {
		if strings.EqualFold(key, "Content-Type") {
			for _, value := range values {
				dst.Add(key, value)
			}
		}
	}
}

func stripICYMetadata(resp *http.Response, onMetadata func(string)) {
	interval, err := strconv.ParseInt(strings.TrimSpace(resp.Header.Get("icy-metaint")), 10, 64)
	if err == nil && interval > 0 {
		resp.Body = &icyMetadataReader{source: resp.Body, interval: interval, audioLeft: interval, onMetadata: onMetadata}
	}
}

type icyMetadataReader struct {
	source     io.Reader
	interval   int64
	audioLeft  int64
	onMetadata func(string)
}

func (r *icyMetadataReader) Close() error {
	if closer, ok := r.source.(io.Closer); ok {
		return closer.Close()
	}
	return nil
}

func (r *icyMetadataReader) Read(buffer []byte) (int, error) {
	if len(buffer) == 0 {
		return 0, nil
	}
	for {
		if r.audioLeft == 0 {
			var size [1]byte
			if _, err := io.ReadFull(r.source, size[:]); err != nil {
				return 0, err
			}
			if metadataBytes := int64(size[0]) * 16; metadataBytes > 0 {
				metadata := make([]byte, metadataBytes)
				if _, err := io.ReadFull(r.source, metadata); err != nil {
					return 0, err
				}
				if r.onMetadata != nil {
					if title, ok := parseICYStreamTitle(metadata); ok {
						r.onMetadata(title)
					}
				}
			}
			r.audioLeft = r.interval
		}
		if int64(len(buffer)) > r.audioLeft {
			buffer = buffer[:r.audioLeft]
		}
		n, err := r.source.Read(buffer)
		r.audioLeft -= int64(n)
		if n > 0 || err != nil {
			return n, err
		}
	}
}

func parseICYStreamTitle(metadata []byte) (string, bool) {
	text := strings.ToValidUTF8(strings.TrimRight(string(metadata), "\x00"), "�")
	key := "streamtitle="
	start := strings.Index(strings.ToLower(text), key)
	if start < 0 {
		return "", false
	}
	value := strings.TrimSpace(text[start+len(key):])
	if value == "" {
		return "", true
	}
	if value[0] == '\'' || value[0] == '"' {
		quote := value[0]
		value = value[1:]
		if end := strings.IndexByte(value, quote); end >= 0 {
			value = value[:end]
		}
	} else if end := strings.IndexByte(value, ';'); end >= 0 {
		value = value[:end]
	}
	return strings.TrimSpace(value), true
}

func wait(ctx context.Context, attempt int) bool {
	delay := time.Second << min(attempt, 3)
	if delay > 8*time.Second {
		delay = 8 * time.Second
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return false
	case <-timer.C:
		return true
	}
}

var sharedAddressSpace = netip.MustParsePrefix("100.64.0.0/10")

func dialPublic(ctx context.Context, network, address string, allowPrivate bool) (net.Conn, error) {
	dialer := &net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second}
	if allowPrivate {
		return dialer.DialContext(ctx, network, address)
	}
	host, port, err := net.SplitHostPort(address)
	if err != nil {
		return nil, err
	}
	var ips []net.IP
	if addr, parseErr := netip.ParseAddr(host); parseErr == nil {
		ips = []net.IP{net.IP(addr.AsSlice())}
	} else {
		resolved, lookupErr := net.DefaultResolver.LookupIPAddr(ctx, host)
		if lookupErr != nil {
			return nil, lookupErr
		}
		for _, item := range resolved {
			ips = append(ips, item.IP)
		}
	}
	var lastErr error
	for _, ip := range ips {
		if !isPublicIP(ip) {
			continue
		}
		conn, dialErr := dialer.DialContext(ctx, network, net.JoinHostPort(ip.String(), port))
		if dialErr == nil {
			return conn, nil
		}
		lastErr = dialErr
	}
	if lastErr != nil {
		return nil, lastErr
	}
	return nil, fmt.Errorf("stream host resolves only to non-public addresses")
}

func isPublicIP(ip net.IP) bool {
	addr, ok := netip.AddrFromSlice(ip)
	if !ok {
		return false
	}
	addr = addr.Unmap()
	if !addr.IsGlobalUnicast() || addr.IsPrivate() || addr.IsLoopback() || addr.IsLinkLocalUnicast() || addr.IsMulticast() || addr.IsUnspecified() {
		return false
	}
	return !sharedAddressSpace.Contains(addr)
}
